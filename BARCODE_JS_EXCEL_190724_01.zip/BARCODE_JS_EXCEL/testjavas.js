

let name1 = 'ajithkrishna';
console.log(name1+"\r");
